# Agent Index

Auto-generated from agent frontmatter. Run `bash scripts/rebuild-index.sh` to refresh.

## Available Agents

| Agent | Emoji | Description | Triggers |
|-------|-------|-------------|----------|
| [domain-researcher](domain-researcher.md) | 🔎 | Research agent summoned before creating new domain experts. Browses web to gather best practices, frameworks, and terminology. | research, create agent, new domain, unfamiliar topic |

_Last updated: 2026-01-29 16:59_
